package com.example.numbercousin

import android.os.Binder
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Toast
import com.example.numbercousin.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity(), View.OnClickListener {
    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.EditButton.setOnClickListener(this)
    }

    override fun onClick(view: View) {
        if (view.id == R.id.Edit_button){
            val result = calculate()
            if (result != null){
                binding.textValue.text = result.toString()
            }
            Toast.makeText(this,"fui clicado", Toast.LENGTH_SHORT).show()
        }
    }
    private fun isValid(): Boolean{
        return (binding.EditNumberOne.text.toString() != ""
                && binding.EditNumberTwo.text.toString() != ""
                && binding.EditOperation.text.toString() != "" )

    }

    fun calculate(): Float? {
        return if (isValid()) {
            val valor1 = binding.EditNumberOne.text.toString().toFloat()
            val valor2 = binding.EditNumberTwo.text.toString().toFloat()
            val operacao = binding.EditOperation.text.toString()
            val value: Float

            when (operacao) {
                "+" -> valor1 + valor2
                "-" -> valor1 - valor2
                "*" -> valor1 * valor2
                "/" -> {
                    if (valor2 != 0f) {
                        valor1 / valor2
                    } else {
                        Toast.makeText(this, "erro", Toast.LENGTH_SHORT).show()
                        null
                    }
                }
                else -> {
                    Toast.makeText(this, "erro", Toast.LENGTH_SHORT).show()
                    null
                }
            }
        } else {
            Toast.makeText(this, "erro", Toast.LENGTH_SHORT).show()
            null
        }
    }

}